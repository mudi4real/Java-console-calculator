package com.company;

//in-built java classes used in the project.
// Scanner is used to collect input from user
import java.util.Scanner;
// Math class contains methods used to calculate basic numeric operations such as trigonometry, ceiling, floor e.t.c.
import java.lang.Math;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // These are the variables declared and used all through the project.
        //I used both int and double cause i felt comfortable working with a particular data type for some operations.
        int option, numb1, results, remainders,  originalNumber;
        double num1, num2, result, gcd, lcm, average;
        // some variables here are assigned values as it is the value I'll be working with for that specific task.
        gcd = 1;
        result = 0;
        results = 0;

        //Here i used the do while loop so that the operation keeps repeating until the user has been satisfied and enters exit to terminate the program.
        do {
            //Here is the display of all the operations that the calculator can perform and numbers beside them to be selected for whatever operation the user chooses to perform.
            System.out.println("Welcome to The Calculator app");
            System.out.println("Please Choose an option");
            System.out.println("1) Add");
            System.out.println("2) Subtract");
            System.out.println("3) Multiply");
            System.out.println("4) Division");
            System.out.println("5) Power");
            System.out.println("6) Square");
            System.out.println("7) Cube");
            System.out.println("8) Square Root");
            System.out.println("9) Round");
            System.out.println("10) Ceiling");
            System.out.println("11) Floor");
            System.out.println("12) Min Value");
            System.out.println("13) Max Value");
            System.out.println("14) Trigonometry Sin Function");
            System.out.println("15) Trigonometry Cos Function");
            System.out.println("16) GCD");
            System.out.println("17) LCM");
            System.out.println("18) Armstrong Number");
            System.out.println("19) Average");
            System.out.println("20) Prime Number");
            System.out.println("21) Continue");
            System.out.println("22) Exit");
            System.out.print("Option :: ");
            // Since an option is meant to be selected, this is the code to collect the number or option selected from the user. It's only an int data type it would collect.
            option = sc.nextInt();
            // Here the switch statement is used to be tested for equality against a list of values.
            switch (option) {
                case 1: {

                    // Here, two separate values are collected from the user and then added using the "+" operator.

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Addition Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here is another prompt for the user to enter a second number.
                    System.out.print("Kindly Enter the SECOND Number :: ");

                    // Here it accepts the second input whether an integer or decimal number cause the double data type is used
                    num2 = sc.nextDouble();

                    //Here the value of the two variables num1 and two are subtracted and assigned to "result"
                    result = num1 + num2;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 2: {

                    // Here, two separate values are collected from the user and then subtracted using the "-" operator.

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Subtraction Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here is another prompt for the user to enter a second number.
                    System.out.print("Kindly Enter the SECOND Number :: ");

                    // Here it accepts the second input whether an integer or decimal number cause the double data type is used
                    num2 = sc.nextDouble();

                    //Here the value of the two variables num1 and num2 are subtracted and assigned to "result"
                    result = num1 - num2;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 3: {

                    // Here, two separate values are collected from the user and then multiplied using the "*" operator.

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Multiplication Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here is another prompt for the user to enter a second number.
                    System.out.print("Kindly Enter the SECOND Number :: ");

                    // Here it accepts the second input whether an integer or decimal number cause the double data type is used
                    num2 = sc.nextDouble();

                    //Here the value of the two variables num1 and num2 are multiplied and assigned to "result"
                    result = num1 * num2;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 4: {

                    // Here, two separate values are collected from the user and then divided using the "/" operator.

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Division Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here is another prompt for the user to enter a second number.
                    System.out.print("Kindly Enter the SECOND Number :: ");

                    // Here it accepts the second input whether an integer or decimal number cause the double data type is used
                    num2 = sc.nextDouble();

                    //Here the value of the two variables num1 and num2 are divided and assigned to "result"
                    result = num1 / num2;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 5: {

                    // Here, two separate values are collected from the user; the first been the main number and the second is the amount the first number is raised to.

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Power Calculator");
                    System.out.print("Kindly Enter the Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here is another prompt for the user to enter the second number.
                    System.out.print("Raised to the power of what:: ");

                    // Here it accepts the second input whether an integer or decimal number cause the double data type is used
                    num2 = sc.nextDouble();

                    //Here it takes 2 arguments as input and returns the value of the first argument raised to the power of the second argument using Math.pow
                    System.out.print("The Result is :: " + Math.pow(num1, num2));

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 6: {

                    // Here a number is collected from the user and is multiplied by itself

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Square Calculator");
                    System.out.print("Kindly Enter the Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    // Here "num1" is multiplied by itself and the value is given to "result" as the square
                    result = num1 * num1;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 7: {

                    // Here a number is collected from the user and is multiplied by itself three times

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Cube Calculator");
                    System.out.print("Kindly Enter the Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    // Here "num1" is multiplied by itself thrice and the value is given to "result" as the cube
                    result = num1 * num1 * num1;

                    //Here a prompt showing that the result has been found
                    System.out.print("The Result is :: ");

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 8: {

                    // Here a number is collected from the user and returns the square root of the argument

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Square Root Calculator");
                    System.out.print("Kindly Enter the Number :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here displays returns the square root of the argument using Math.sqrt.
                    System.out.print("The Result is :: " + Math.sqrt(num1));

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 9: {

                    // Here a number is collected from the user and returns the closed int or long (as per the argument)

                    //The next two lines of code display what operation the user is working with and the prompt for the user to enter a number.
                    System.out.println("Round Calculator");
                    System.out.print("Kindly Enter The Number To Round :: ");

                    // Here it accepts the input whether an integer or decimal number cause the double data type is used
                    num1 = sc.nextDouble();

                    //Here displays and returns the rounded number using Math.round.
                    System.out.print("The Result is :: " + Math.round(num1));

                    //Here the result is displayed
                    System.out.println(result);
                    break;
                }
                case 10: {


                    System.out.println("Ceiling Calculator");
                    System.out.print("Kindly Enter The Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("The Result is :: " + Math.ceil(num1));
                    System.out.println(result);
                    break;
                }
                case 11: {
                    System.out.println("Floor Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("The Result is :: " + Math.floor(num1));
                    System.out.println(result);
                    break;
                }
                case 12: {
                    System.out.println("Min Value Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("Kindly Enter the SECOND Number :: ");
                    num2 = sc.nextDouble();
                    System.out.print("The Minimum value out of '" + num1 + "' and '" + num2 + "' =  " + Math.min(num1, num2));
                    System.out.println(result);
                    break;
                }
                case 13: {
                    System.out.println("Max Value Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("Kindly Enter the SECOND Number :: ");
                    num2 = sc.nextDouble();
                    System.out.print("The Maximum value out of '" + num1 + "' and '" + num2 + "' =  " + Math.max(num1, num2));
                    System.out.println(result);
                    break;
                }
                case 14: {
                    System.out.println("Trigonometry Sin Function Calculator");
                    System.out.print("Kindly Enter The Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("The Result is :: " + Math.sin(num1));
                    System.out.println(result);
                    break;
                }
                case 15: {
                    System.out.println("Trigonometry Cos Function Calculator");
                    System.out.print("Kindly Enter The Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("The Result is :: " + Math.cos(num1));
                    System.out.println(result);
                    break;
                }
                case 16: {
                    System.out.println("GCD Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("Kindly Enter the SECOND number:: ");
                    num2 = sc.nextDouble();
                    for(int i = 1; i <= num1 && i <= num2; ++i)
                    {
                        // Checks if i is factor of both integers
                        if(num1 % i==0 && num2 % i==0)
                            gcd = i;
                    }
                    System.out.print("The GCD of '" + num1 + "' and '" + num2 + "' =  " + gcd);
                    System.out.println(result);
                    break;
                }
                case 17: {
                    System.out.println("LCM Calculator");
                    System.out.print("Kindly Enter the FIRST Number :: ");
                    num1 = sc.nextDouble();
                    System.out.print("Kindly Enter the SECOND number:: ");
                    num2 = sc.nextDouble();
                    for(int i = 1; i <= num1 && i <= num2; ++i)
                    {
                        // Checks if i is factor of both integers
                        if(num1 % i == 0 && num2 % i == 0)
                            gcd = i;
                    }

                    lcm = (num1 * num2) / gcd;
                    System.out.println("The LCM of '" + num1 + "' and '" + num2 + "' =  " + lcm);
                    System.out.println(result);
                    break;
                }
                case 18: {
                    System.out.println("Armstrong Number Calculator");
                    System.out.print("Kindly Enter the Number :: ");
                    numb1 = sc.nextInt();
                    originalNumber = numb1;

                    while (originalNumber != 0)
                    {
                        remainders = originalNumber % 10;
                        results += Math.pow(remainders, 3);
                        originalNumber /= 10;
                    }

                    if(results == numb1)
                        System.out.println(numb1 + " is an Armstrong number.");
                    else
                        System.out.println(numb1 + " is not an Armstrong number.");
                    break;
                }
                case 19: {
                    System.out.println("Average Calculator");
                    System.out.print("How Many Numbers are you Calculating :: ");
                    numb1 = sc.nextInt();
                    int a[] = new int[numb1];
                    System.out.print("Kindly Enter All the numbers :: ");
                    for(int i = 0; i < numb1 ; i++)
                    {
                        a[i] = sc.nextInt();
                        result = result + a[i];
                    }
                    System.out.println("Sum:"+result);
                    average = (double) result / numb1;
                    System.out.println("Average:"+average);
                    System.out.println(result);
                    break;
                }
                case 20: {
                    System.out.println("Prime Number Calculator");
                    System.out.print("Kindly Enter the Number :: ");
                    numb1 = sc.nextInt();
                    boolean flag = false;
                    for(int i = 2; i <= numb1/2; ++i)
                    {
                        // condition for nonprime number
                        if(numb1 % i == 0)
                        {
                            flag = true;
                            break;
                        }
                    }

                    if (!flag)
                        System.out.println(numb1 + " is a prime number.");
                    else
                        System.out.println(numb1 + " is not a prime number.");
                    break;
                }
                case 21: {
                    System.out.println("Please Choose an option");
                    System.out.println("1) Add");
                    System.out.println("2) Subtract");
                    System.out.println("3) Multiply");
                    System.out.print("Option :: ");
                    option = sc.nextInt();
                    switch (option) {
                        case 1: {
                            System.out.println("Addition Calculator");
                            System.out.print("Kindly Enter the SECOND Number :: ");
                            num2 = sc.nextDouble();
                            result = result + num2;
                            System.out.print("The Result is :: ");
                            System.out.println(result);
                            break;
                        }
                        case 2: {
                            System.out.println("Subtraction Calculator");
                            System.out.print("Kindly Enter the SECOND Number :: ");
                            num2 = sc.nextDouble();
                            result = result - num2;
                            System.out.print("The Result is :: ");
                            System.out.println(result);
                            break;
                        }
                        case 3: {
                            System.out.println("Multiplication Calculator");
                            System.out.print("Kindly Enter the SECOND Number :: ");
                            num2 = sc.nextDouble();
                            result = result * num2;
                            System.out.print("The Result is :: ");
                            System.out.println(result);
                            break;
                        }
                    }
                    break;
                }
                case 22: {
                    System.out.println("Thank you for using my program :: ");
                    System.out.println("Program will now exit ");
                    System.exit(0);
                }
            }
        } while (option != 22);
    }
}
